# CameronCodesStuff.github.io

There will be regular updates.                                               Link to site: https://cameroncodesstuff.github.io/     or     cameroncodesstuff.github.io                                               If you find any bugs or have any suggestions email me at: detlaffcameron@gmail.com                                                                     
(v then a number is the version (the higher the number the later the version))
index.html is the main code file.

If you would like to see the code download "index.html" the  go onto (https://twinery.org/) and then import the "index.html".

Made by CameronCodesStuff                                                                                                                                                                                                                                                                                                                                          
